import 'package:flutter/material.dart';

// 北京家乡介绍数据模型 / 北京家乡介绍数据模型
// 用于展示景点、美食、推荐路线等内容卡片
class Attraction {
  final String title; // 标题 / 标题
  final String subtitle; // 列表页副标题（一句话简介） / 列表页副标题（一句话简介）
  final String imageUrl; // 图片地址（网络图片） / 图片地址（网络图片）
  final String detail; // 详情页正文介绍 / 详情页正文介绍
  final String category; // 分类标签：景点 / 美食 / 路线 / 分类标签：景点/美食/路线
  final IconData categoryIcon; // 分类图标 / 分类图标

  const Attraction({
    required this.title,
    required this.subtitle,
    required this.imageUrl,
    required this.detail,
    required this.category,
    required this.categoryIcon,
  });
}
